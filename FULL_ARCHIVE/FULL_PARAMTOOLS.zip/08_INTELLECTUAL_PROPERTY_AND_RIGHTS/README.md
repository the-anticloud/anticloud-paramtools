# 08 Intellectual Property And Rights

**Project:** PARAMTOOLS
**Upstream:** https://github.com/paramtools/paramtools

Content specific to PARAMTOOLS in category ARCHITECTURAL_DESIGN.
