# 05 Commitments To Past Present Future

**Project:** PARAMTOOLS
**Upstream:** https://github.com/paramtools/paramtools

Content specific to PARAMTOOLS in category ARCHITECTURAL_DESIGN.
