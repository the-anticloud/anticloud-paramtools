# 19 System Of Things Sot

**Project:** PARAMTOOLS
**Upstream:** https://github.com/paramtools/paramtools

Content specific to PARAMTOOLS in category ARCHITECTURAL_DESIGN.
